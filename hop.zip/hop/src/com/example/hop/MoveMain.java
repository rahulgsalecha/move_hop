package com.example.hop;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MoveMain extends Activity
{
  private static String logtag = "Main App";
  Button buttonMover;
  Button buttonUser;

  public void addListenerOnButton()
  {
    Button localButton1 = (Button)findViewById(2131492894);
    Button localButton2 = (Button)findViewById(2131492895);
    localButton1.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(MoveMain.this.getBaseContext(), MoverDetails.class);
        MoveMain.this.startActivityForResult(localIntent, 0);
      }
    });
    localButton2.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(MoveMain.this.getBaseContext(), UserDetails.class);
        MoveMain.this.startActivityForResult(localIntent, 1);
      }
    });
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    switch (paramInt1)
    {
    default:
    case 0:
    case 1:
    	
    }
    do
      return;
    while (paramInt2 != -1);
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903041);
    addListenerOnButton();
  }

  protected void onDestroy()
  {
    Log.d(logtag, "onDestroy() called");
    super.onDestroy();
  }

  protected void onPause()
  {
    Log.d(logtag, "onPause() called");
    super.onPause();
  }

  protected void onRestart()
  {
    super.onRestart();
  }

  protected void onResume()
  {
    Log.d(logtag, "onResume() called");
    super.onResume();
  }

  protected void onStart()
  {
    Log.d(logtag, "onStart() called");
    super.onStart();
  }

  protected void onStop()
  {
    Log.d(logtag, "onStop() called");
    super.onStop();
  }
}

/* Location:           /Users/rsalecha/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.example.hop.MoveMain
 * JD-Core Version:    0.6.2
 */