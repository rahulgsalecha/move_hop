package com.example.hop;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import com.parse.ParseObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class UserDetails extends Activity
  implements View.OnClickListener, TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener
{
  private static String logtag = "UserDetails Page";
  SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd");
  ParseObject UserDataStore = new ParseObject("UserDataStore");
  Button buttonSubmit;
  private String date_data;
  private String end_time;
  private String location;
  private Spinner spinner1;
  private String start_time;
  private TextView textview1;
  private TextView textview2;
  private TextView textview3;
  private TextView textview4;
  private String user_data;

  public void addListenerOnButtonClick()
  {
    this.buttonSubmit = ((Button)findViewById(2131492901));
    this.buttonSubmit.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(UserDetails.this.getBaseContext(), UserSelections.class);
        localIntent.putExtra("user", UserDetails.this.user_data);
        localIntent.putExtra("start_time", UserDetails.this.start_time);
        localIntent.putExtra("end_time", UserDetails.this.end_time);
        localIntent.putExtra("date", UserDetails.this.date_data);
        localIntent.putExtra("location", UserDetails.this.location);
        UserDetails.this.startActivityForResult(localIntent, 0);
      }
    });
  }

  public void addListenerOnSpinnerItemSelection()
  {
    this.spinner1 = ((Spinner)findViewById(2131492896));
    this.spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
    {
      public void onItemSelected(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
      {
        UserDetails.this.user_data = UserDetails.this.spinner1.getSelectedItem().toString();
        UserDetails.this.UserDataStore.put("user", UserDetails.this.user_data);
        UserDetails.this.UserDataStore.saveInBackground();
      }

      public void onNothingSelected(AdapterView<?> paramAnonymousAdapterView)
      {
      }
    });
  }

  public void addListenerOnTextView()
  {
    this.textview1 = ((TextView)findViewById(2131492897));
    this.textview2 = ((TextView)findViewById(2131492898));
    this.textview3 = ((TextView)findViewById(2131492899));
    this.textview4 = ((TextView)findViewById(2131492900));
    this.textview1.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        new UserDetails.TimePickerFragmentStart(UserDetails.this).show(UserDetails.this.getFragmentManager(), "timePicker");
      }
    });
    this.textview2.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        new UserDetails.TimePickerFragmentEnd(UserDetails.this).show(UserDetails.this.getFragmentManager(), "timePicker1");
      }
    });
    this.textview3.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        new UserDetails.DatePickerDialogFragment(UserDetails.this).show(UserDetails.this.getFragmentManager(), "datePicker");
      }
    });
    this.textview4.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(UserDetails.this.getBaseContext(), LocationDetails.class);
        localIntent.putExtra("type", "user");
        UserDetails.this.startActivityForResult(localIntent, 1);
      }
    });
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt1 == 1)
    {
      this.location = paramIntent.getStringExtra("address");
      this.textview4.setText(this.location);
      this.UserDataStore.put("location", this.location);
      this.UserDataStore.saveInBackground();
    }
    if (paramInt1 == 0)
    {
      addListenerOnSpinnerItemSelection();
      addListenerOnTextView();
      addListenerOnButtonClick();
    }
  }

  public void onBackPressed()
  {
    setResult(-1, new Intent());
    finish();
  }

  public void onClick(View paramView)
  {
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903043);
    addListenerOnSpinnerItemSelection();
    addListenerOnTextView();
    addListenerOnButtonClick();
  }

  public void onDateSet(DatePicker paramDatePicker, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  protected void onDestroy()
  {
    Log.d(logtag, "onDestroy() called");
    super.onDestroy();
  }

  protected void onPause()
  {
    Log.d(logtag, "onPause() called");
    super.onPause();
  }

  protected void onRestart()
  {
    super.onRestart();
  }

  protected void onResume()
  {
    Log.d(logtag, "onResume() called");
    super.onResume();
  }

  protected void onStart()
  {
    Log.d(logtag, "onStart() called");
    super.onStart();
  }

  protected void onStop()
  {
    Log.d(logtag, "onStop() called");
    super.onStop();
  }

  public void onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2)
  {
  }

  public class DatePickerDialogFragment extends DialogFragment
    implements DatePickerDialog.OnDateSetListener
  {
    private DatePickerDialog.OnDateSetListener mDateSetListener;

    public DatePickerDialogFragment()
    {
    }

    public DatePickerDialogFragment(DatePickerDialog.OnDateSetListener arg2)
    {
      Object localObject = null;
      this.mDateSetListener = (OnDateSetListener) localObject;
    }

    public Dialog onCreateDialog(Bundle paramBundle)
    {
      Calendar localCalendar = Calendar.getInstance();
      return new DatePickerDialog(getActivity(), this, localCalendar.get(1), localCalendar.get(2), localCalendar.get(5));
    }

    public void onDateSet(DatePicker paramDatePicker, int paramInt1, int paramInt2, int paramInt3)
    {
      GregorianCalendar localGregorianCalendar = new GregorianCalendar(paramInt1, paramInt2, paramInt3);
      UserDetails.this.textview3.setText(UserDetails.this.DATE_FORMATTER.format(localGregorianCalendar.getTime()));
      UserDetails.this.date_data = UserDetails.this.textview3.getText().toString();
      UserDetails.this.UserDataStore.put("date", UserDetails.this.date_data);
      UserDetails.this.UserDataStore.saveInBackground();
    }
  }

  public class TimePickerFragmentEnd extends DialogFragment
    implements TimePickerDialog.OnTimeSetListener
  {
    private TimePickerDialog.OnTimeSetListener mTimeSetListener;

    public TimePickerFragmentEnd()
    {
    }

    public TimePickerFragmentEnd(TimePickerDialog.OnTimeSetListener arg2)
    {
      Object localObject = null;
      this.mTimeSetListener = (OnTimeSetListener) localObject;
    }

    public Dialog onCreateDialog(Bundle paramBundle)
    {
      Calendar localCalendar = Calendar.getInstance();
      return new TimePickerDialog(getActivity(), this, localCalendar.get(11), localCalendar.get(12), DateFormat.is24HourFormat(getActivity()));
    }

    public void onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2)
    {
      UserDetails.this.textview2.setText(paramInt1 + ":" + paramInt2);
      UserDetails.this.end_time = UserDetails.this.textview2.getText().toString();
      UserDetails.this.UserDataStore.put("end_time", UserDetails.this.end_time);
      UserDetails.this.UserDataStore.saveInBackground();
    }
  }

  public class TimePickerFragmentStart extends DialogFragment
    implements TimePickerDialog.OnTimeSetListener
  {
    private TimePickerDialog.OnTimeSetListener mTimeSetListener;

    public TimePickerFragmentStart()
    {
    }

    public TimePickerFragmentStart(TimePickerDialog.OnTimeSetListener arg2)
    {
      Object localObject = null;
      this.mTimeSetListener = (OnTimeSetListener) localObject;
    }

    public Dialog onCreateDialog(Bundle paramBundle)
    {
      Calendar localCalendar = Calendar.getInstance();
      return new TimePickerDialog(getActivity(), this, localCalendar.get(11), localCalendar.get(12), DateFormat.is24HourFormat(getActivity()));
    }

    public void onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2)
    {
      UserDetails.this.textview1.setText(paramInt1 + ":" + paramInt2);
      UserDetails.this.start_time = UserDetails.this.textview1.getText().toString();
      UserDetails.this.UserDataStore.put("start_time", UserDetails.this.start_time);
      UserDetails.this.UserDataStore.saveInBackground();
    }
  }
}

/* Location:           /Users/rsalecha/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.example.hop.UserDetails
 * JD-Core Version:    0.6.2
 */