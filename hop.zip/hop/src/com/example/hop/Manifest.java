package com.example.hop;

public final class Manifest
{
  public static final class permission
  {
    public static final String MAPS_RECEIVE = "com.example.hop.googlemapsv2.permission.MAPS_RECEIVE";
  }
}

/* Location:           /Users/rsalecha/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.example.hop.Manifest
 * JD-Core Version:    0.6.2
 */