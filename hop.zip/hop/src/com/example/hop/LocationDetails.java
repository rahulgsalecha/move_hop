package com.example.hop;

import android.app.Activity;
import android.app.Dialog;
import android.app.FragmentManager;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.Builder;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.FusedLocationProviderApi;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnCameraChangeListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class LocationDetails extends Activity
implements LocationListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener
{
	public static double ShopLat;
	public static double ShopLong;
	public static String ShopPlaceId;
	private TextView Address;
	private List<Address> addresses;
	private LatLng center;
	private FusedLocationProviderApi fusedLocationProviderApi = LocationServices.FusedLocationApi;
	private Geocoder geocoder;
	GoogleMap mGoogleMap;
	private GoogleApiClient mLocationClient = null;
	private LocationRequest mLocationRequest;
	boolean mUpdatesRequested = false;
	private LinearLayout markerLayout;
	private TextView markerText;
	public String selected_address;

	private void stupMap()
	{
		try
		{
			this.mGoogleMap = ((MapFragment)getFragmentManager().findFragmentById(2131492888)).getMap();
			this.mGoogleMap.setMyLocationEnabled(true);
			LatLng localLatLng = null;
			if (LocationServices.FusedLocationApi.getLastLocation(this.mLocationClient) != null)
			{
				localLatLng = new LatLng(LocationServices.FusedLocationApi.getLastLocation(this.mLocationClient).getLatitude(), LocationServices.FusedLocationApi.getLastLocation(this.mLocationClient).getLongitude());
				ShopLat = LocationServices.FusedLocationApi.getLastLocation(this.mLocationClient).getLatitude();
				ShopLong = LocationServices.FusedLocationApi.getLastLocation(this.mLocationClient).getLongitude();
			}
			while (true)
			{
				CameraPosition localCameraPosition = new CameraPosition.Builder().target(localLatLng).zoom(19.0F).tilt(70.0F).build();
				this.mGoogleMap.setMyLocationEnabled(true);
				this.mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(localCameraPosition));
				this.mGoogleMap.clear();
				this.mGoogleMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener()
				{
					public void onCameraChange(CameraPosition paramAnonymousCameraPosition)
					{
						LocationDetails.this.center = LocationDetails.this.mGoogleMap.getCameraPosition().target;
						LocationDetails.this.markerText.setText(" Set your Location ");
						LocationDetails.this.mGoogleMap.clear();
						LocationDetails.this.markerLayout.setVisibility(0);
						try
						{
							new LocationDetails.GetLocationAsync(LocationDetails.this.center.latitude, LocationDetails.this.center.longitude).execute(new String[0]);
							return;
						}
						catch (Exception localException)
						{
						}
					}
				});
				this.markerLayout.setOnClickListener(new View.OnClickListener()
				{
					public void onClick(View paramAnonymousView)
					{
						try
						{
							LatLng localLatLng = new LatLng(LocationDetails.this.center.latitude, LocationDetails.this.center.longitude);
							LocationDetails.this.mGoogleMap.addMarker(new MarkerOptions().position(localLatLng).title(" Set your Location ").snippet("").icon(BitmapDescriptorFactory.fromResource(2130837504))).setDraggable(true);
							LocationDetails.this.markerLayout.setVisibility(8);
							return;
						}
						catch (Exception localException)
						{
						}
					}
				});
				this.markerText.setOnClickListener(new View.OnClickListener()
				{
					public void onClick(View paramAnonymousView)
					{
						LocationDetails.this.selected_address = LocationDetails.this.Address.getText().toString();
						String str = LocationDetails.this.getIntent().getStringExtra("type");
						Intent localIntent = new Intent();
						localIntent.putExtra("address", LocationDetails.this.selected_address);
						if (str.equalsIgnoreCase("mover"))
							LocationDetails.this.setResult(2, localIntent);
						while (true)
						{
							LocationDetails.this.finish();
							return;
						}
					}
				});
				return;
			}
		}
		catch (Exception localException)
		{
			localException.printStackTrace();
		}
	}

	public void onConnected(Bundle paramBundle)
	{
		stupMap();
	}

	public void onConnectionFailed(ConnectionResult paramConnectionResult)
	{
	}

	public void onConnectionSuspended(int paramInt)
	{
	}

	protected void onCreate(Bundle paramBundle)
	{
		super.onCreate(paramBundle);
		setContentView(2130903040);
		this.markerText = ((TextView)findViewById(2131492890));
		this.Address = ((TextView)findViewById(2131492893));
		this.markerLayout = ((LinearLayout)findViewById(2131492889));
		int i = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getBaseContext());
		if (i != 0)
		{
			GooglePlayServicesUtil.getErrorDialog(i, this, 10).show();
			return;
		}
		this.mLocationRequest = LocationRequest.create();
		this.mLocationRequest.setInterval(5000L);
		this.mLocationRequest.setPriority(100);
		this.mLocationRequest.setFastestInterval(1000L);
		this.mUpdatesRequested = false;
		this.mLocationClient = new GoogleApiClient.Builder(getBaseContext()).addApi(LocationServices.API).addConnectionCallbacks(this).addOnConnectionFailedListener(this).build();
		this.mLocationClient.connect();
	}

	public void onDisconnected()
	{
	}

	public void onLocationChanged(Location paramLocation)
	{
	}

	public void onProviderDisabled(String paramString)
	{
	}

	public void onProviderEnabled(String paramString)
	{
	}

	public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle)
	{
	}

	private class GetLocationAsync extends AsyncTask<String, Void, String>
	{
		StringBuilder str;
		double x;
		double y;

		public GetLocationAsync(double arg2, double arg4)
		{
			this.x = Object localObject;
			
			this.y = (Double) localObject;
		}

		protected String doInBackground(String[] paramArrayOfString)
		{
			try
			{
				LocationDetails.this.geocoder = new Geocoder(LocationDetails.this, Locale.ENGLISH);
				LocationDetails.this.addresses = LocationDetails.this.geocoder.getFromLocation(this.x, this.y, 1);
				this.str = new StringBuilder();
				if (Geocoder.isPresent())
				{
					Address localAddress = (Address)LocationDetails.this.addresses.get(0);
					String str1 = localAddress.getLocality();
					String str2 = localAddress.getCountryName();
					String str3 = localAddress.getCountryCode();
					String str4 = localAddress.getPostalCode();
					this.str.append(str1);
					this.str.append(str2 + str3);
					this.str.append(str4);
				}
				return null;
			}
			catch (IOException localIOException)
			{
				while (true)
					Log.e("tag", localIOException.getMessage());
			}
		}

		protected void onPostExecute(String paramString)
		{
			try
			{
				LocationDetails.this.Address.setText(((Address)LocationDetails.this.addresses.get(0)).getAddressLine(0) + " " + ((Address)LocationDetails.this.addresses.get(0)).getAddressLine(1) + " ");
				return;
			}
			catch (Exception localException)
			{
				localException.printStackTrace();
			}
		}

		protected void onPreExecute()
		{
			LocationDetails.this.Address.setText(" Getting location ");
		}

		protected void onProgressUpdate(Void[] paramArrayOfVoid)
		{
		}
	}
}

/* Location:           /Users/rsalecha/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.example.hop.LocationDetails
 * JD-Core Version:    0.6.2
 */