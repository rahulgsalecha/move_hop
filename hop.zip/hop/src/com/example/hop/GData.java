package com.example.hop;

public class GData
{
	public static final int FAST_CEILING_IN_SECONDS = 1;
	public static final long FAST_INTERVAL_CEILING_IN_MILLISECONDS = 1000L;
	public static final int MILLISECONDS_PER_SECOND = 1000;
	public static final long UPDATE_INTERVAL_IN_MILLISECONDS = 5000L;
	public static final int UPDATE_INTERVAL_IN_SECONDS = 5;
}
