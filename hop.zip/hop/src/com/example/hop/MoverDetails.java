package com.example.hop;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import com.parse.ParseObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class MoverDetails extends Activity
  implements View.OnClickListener, TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener
{
  private static String logtag = "MoverDetails Page";
  SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd");
  ParseObject MoverDataStore = new ParseObject("MoverDataStore");
  private String date_data;
  private String end_time;
  private String location;
  private String mover_data;
  private Spinner spinner1;
  private String start_time;
  private TextView textview1;
  private TextView textview2;
  private TextView textview3;
  private TextView textview4;

  public void addListenerOnSpinnerItemSelection()
  {
    this.spinner1 = ((Spinner)findViewById(2131492896));
    this.spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
    {
      public void onItemSelected(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
      {
        MoverDetails.this.mover_data = MoverDetails.this.spinner1.getSelectedItem().toString();
        MoverDetails.this.MoverDataStore.put("mover", MoverDetails.this.mover_data);
        MoverDetails.this.MoverDataStore.saveInBackground();
      }

      public void onNothingSelected(AdapterView<?> paramAnonymousAdapterView)
      {
      }
    });
  }

  public void addListenerOnTextView()
  {
    this.textview1 = ((TextView)findViewById(2131492897));
    this.textview2 = ((TextView)findViewById(2131492898));
    this.textview3 = ((TextView)findViewById(2131492899));
    this.textview4 = ((TextView)findViewById(2131492900));
    this.textview1.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        new MoverDetails.TimePickerFragmentStart(MoverDetails.this).show(MoverDetails.this.getFragmentManager(), "timePicker");
      }
    });
    this.textview2.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        new MoverDetails.TimePickerFragmentEnd(MoverDetails.this).show(MoverDetails.this.getFragmentManager(), "timePicker1");
      }
    });
    this.textview3.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        new MoverDetails.DatePickerDialogFragment(MoverDetails.this).show(MoverDetails.this.getFragmentManager(), "datePicker");
      }
    });
    this.textview4.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(MoverDetails.this.getBaseContext(), LocationDetails.class);
        localIntent.putExtra("type", "mover");
        MoverDetails.this.startActivityForResult(localIntent, 2);
      }
    });
  }

  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramInt1 == 2)
    {
      this.location = paramIntent.getStringExtra("address");
      this.textview4.setText(this.location);
      this.MoverDataStore.put("location", this.location);
      this.MoverDataStore.saveInBackground();
    }
  }

  public void onBackPressed()
  {
    setResult(-1, new Intent());
    finish();
  }

  public void onClick(View paramView)
  {
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903042);
    addListenerOnSpinnerItemSelection();
    addListenerOnTextView();
  }

  public void onDateSet(DatePicker paramDatePicker, int paramInt1, int paramInt2, int paramInt3)
  {
  }

  protected void onDestroy()
  {
    Log.d(logtag, "onDestroy() called");
    super.onDestroy();
  }

  protected void onPause()
  {
    Log.d(logtag, "onPause() called");
    super.onPause();
  }

  protected void onRestart()
  {
    super.onRestart();
  }

  protected void onResume()
  {
    Log.d(logtag, "onResume() called");
    super.onResume();
  }

  protected void onStart()
  {
    Log.d(logtag, "onStart() called");
    super.onStart();
  }

  protected void onStop()
  {
    Log.d(logtag, "onStop() called");
    super.onStop();
  }

  public void onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2)
  {
  }

  public class DatePickerDialogFragment extends DialogFragment
    implements DatePickerDialog.OnDateSetListener
  {
    private DatePickerDialog.OnDateSetListener mDateSetListener;

    public DatePickerDialogFragment()
    {
    }

    public DatePickerDialogFragment(DatePickerDialog.OnDateSetListener arg2)
    {
      Object localObject = null;
      this.mDateSetListener = (OnDateSetListener) localObject;
    }

    public Dialog onCreateDialog(Bundle paramBundle)
    {
      Calendar localCalendar = Calendar.getInstance();
      return new DatePickerDialog(getActivity(), this, localCalendar.get(1), localCalendar.get(2), localCalendar.get(5));
    }

    public void onDateSet(DatePicker paramDatePicker, int paramInt1, int paramInt2, int paramInt3)
    {
      GregorianCalendar localGregorianCalendar = new GregorianCalendar(paramInt1, paramInt2, paramInt3);
      MoverDetails.this.textview3.setText(MoverDetails.this.DATE_FORMATTER.format(localGregorianCalendar.getTime()));
      MoverDetails.this.date_data = MoverDetails.this.textview3.getText().toString();
      MoverDetails.this.MoverDataStore.put("date", MoverDetails.this.date_data);
      MoverDetails.this.MoverDataStore.saveInBackground();
    }
  }

  public class TimePickerFragmentEnd extends DialogFragment
    implements TimePickerDialog.OnTimeSetListener
  {
    private TimePickerDialog.OnTimeSetListener mTimeSetListener;

    public TimePickerFragmentEnd()
    {
    }

    public TimePickerFragmentEnd(TimePickerDialog.OnTimeSetListener arg2)
    {
      Object localObject = null;
      this.mTimeSetListener = (OnTimeSetListener) localObject;
    }

    public Dialog onCreateDialog(Bundle paramBundle)
    {
      Calendar localCalendar = Calendar.getInstance();
      return new TimePickerDialog(getActivity(), this, localCalendar.get(11), localCalendar.get(12), DateFormat.is24HourFormat(getActivity()));
    }

    public void onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2)
    {
      MoverDetails.this.textview2.setText(paramInt1 + ":" + paramInt2);
      MoverDetails.this.end_time = MoverDetails.this.textview2.getText().toString();
      MoverDetails.this.MoverDataStore.put("end_time", MoverDetails.this.end_time);
      MoverDetails.this.MoverDataStore.saveInBackground();
    }
  }

  public class TimePickerFragmentStart extends DialogFragment
    implements TimePickerDialog.OnTimeSetListener
  {
    private TimePickerDialog.OnTimeSetListener mTimeSetListener;

    public TimePickerFragmentStart()
    {
    }

    public TimePickerFragmentStart(TimePickerDialog.OnTimeSetListener arg2)
    {
      Object localObject = null;
      this.mTimeSetListener = (OnTimeSetListener) localObject;
    }

    public Dialog onCreateDialog(Bundle paramBundle)
    {
      Calendar localCalendar = Calendar.getInstance();
      return new TimePickerDialog(getActivity(), this, localCalendar.get(11), localCalendar.get(12), DateFormat.is24HourFormat(getActivity()));
    }

    public void onTimeSet(TimePicker paramTimePicker, int paramInt1, int paramInt2)
    {
      MoverDetails.this.textview1.setText(paramInt1 + ":" + paramInt2);
      MoverDetails.this.start_time = MoverDetails.this.textview1.getText().toString();
      MoverDetails.this.MoverDataStore.put("start_time", MoverDetails.this.start_time);
      MoverDetails.this.MoverDataStore.saveInBackground();
    }
  }
}

/* Location:           /Users/rsalecha/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.example.hop.MoverDetails
 * JD-Core Version:    0.6.2
 */